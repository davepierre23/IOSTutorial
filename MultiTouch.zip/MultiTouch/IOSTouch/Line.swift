//
//  Line.swift
//  IOSTouch
//
//  Created by Dave Pierre on 2021-03-08.
//

import Foundation
import CoreGraphics

struct Line {
    var begin = CGPoint.zero
    var end = CGPoint.zero
}
