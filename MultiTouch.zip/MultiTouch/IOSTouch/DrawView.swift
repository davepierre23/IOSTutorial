//
//  DrawView.swift
//  IOSTouch
//
//  Created by Dave Pierre on 2021-03-08.
//

import UIKit

class DrawView: UIView {
    var currentLines = [NSValue:Line]() //dictionary of key-value pairs
    var finishedLines = [Line]()
  //for debug
    var selectedLineIndex: Int?

    
    required init?(coder aDecoder: NSCoder){
       super.init(coder: aDecoder)
       let doubleTapRecognizer =
          UITapGestureRecognizer(target: self,
                                 action: #selector(DrawView.doubleTap(_:)))
       doubleTapRecognizer.numberOfTapsRequired = 2
       doubleTapRecognizer.delaysTouchesBegan = true
       addGestureRecognizer(doubleTapRecognizer)
        
        let tapRecognizer = 
               UITapGestureRecognizer(target: self,
                                      action: #selector(DrawView.tap(_:)))
           tapRecognizer.delaysTouchesBegan = true
           tapRecognizer.require(toFail: doubleTapRecognizer) //<========
       tapRecognizer.delaysTouchesBegan = true
       addGestureRecognizer(tapRecognizer)

    }
            

    @objc func doubleTap(_ gestureRecognizer: UIGestureRecognizer){
        print("I got a double tap")
        if(selectedLineIndex != nil){
            finishedLines.remove(at: selectedLineIndex!)
            selectedLineIndex = nil //<======================

        }else{
            currentLines.removeAll(keepingCapacity: false)
            finishedLines.removeAll(keepingCapacity: false)
        }
  
        setNeedsDisplay()
    }

    @objc func tap(_ gestureRecognizer: UIGestureRecognizer){
        print("I got a tap")
        let tapPoint = gestureRecognizer.location(in: self)
        selectedLineIndex = indexOfLineNearPoint(point: tapPoint)
        setNeedsDisplay()
    }
    
    func distanceBetween(from: CGPoint, to: CGPoint) -> CFloat{
        let distXsquared = Float((to.x-from.x)*(to.x-from.x))
        let distYsquared = Float((to.y-from.y)*(to.y-from.y))
        return sqrt(distXsquared + distYsquared);
    }
    
    func indexOfLineNearPoint(point: CGPoint) -> Int? {
        let tolerence: Float = 1.0 //experiment with this value
        for(index,line) in finishedLines.enumerated(){
            let begin = line.begin
            let end = line.end
            let lineLength = distanceBetween(from: begin, to: end)
            let beginToTapDistance = distanceBetween(from: begin, to: point)
            let endToTapDistance = distanceBetween(from: end, to: point)
            if (beginToTapDistance + endToTapDistance - lineLength) < tolerence {
                return index
            }
        }
        return nil
    }

   

    @IBInspectable var finishedLineColor: UIColor = UIColor.black {
        didSet {
            setNeedsDisplay()
        }
    }
    @IBInspectable var currentLineColor: UIColor = UIColor.red {
        didSet {
            setNeedsDisplay()
        }
    }
    @IBInspectable var lineThickness: CGFloat = 10 {
        didSet {
            setNeedsDisplay()
        }
    }
 
    
    //Override Touch Functions
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?){
          for touch in touches {
              let location = touch.location(in: self)
              let newLine = Line(begin: location, end: location)
              let key = NSValue(nonretainedObject: touch)
              currentLines[key] = newLine
          }
          setNeedsDisplay(); //this view needs to be updated
      }

    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let location = touch.location(in: self)
            let newLine = Line(begin: location, end: location)
            let key = NSValue(nonretainedObject: touch)
            currentLines[key]?.end = newLine.end;
            setNeedsDisplay(); //this view needs to be updated
        }

    }

      override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let key = NSValue(nonretainedObject: touch)
            finishedLines.append(currentLines[key]!);
            currentLines[key]! = Line();
            setNeedsDisplay(); //this view needs to be updated
        }
      }

      override func touchesCancelled(_ touches: Set<UITouch>?, with event: UIEvent?) {
        currentLines = [NSValue:Line]() ;
        setNeedsDisplay(); //this view needs to be updated
      }

  func strokeLine(line: Line){
        //Use BezierPath to draw lines
        let path = UIBezierPath();
        path.lineWidth = lineThickness;
        path.lineCapStyle = CGLineCap.round;
        
        path.move(to: line.begin);
        path.addLine(to: line.end);
        path.stroke(); //actually draw the path
    }
    

    override func draw(_ rect: CGRect) {
        
        //draw the finished lines
        finishedLineColor.setStroke() //set colour to draw
        for line in finishedLines{
            strokeLine(line: line);
        }
        

        ///draw current line if it exists
        for (_,line) in currentLines{
                currentLineColor.setStroke()
                strokeLine(line: line)
        }
        for line in currentLines{
          
                currentLineColor.setStroke(); //set colour to draw
            strokeLine(line: line.value);
        
        }
        if let index = selectedLineIndex {
            UIColor.yellow.setStroke()
            let selectedLine = finishedLines[index]
            strokeLine(line: selectedLine)
        }

 
    }
}
